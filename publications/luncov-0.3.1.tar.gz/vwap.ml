open Commons
open Cil_types

(** Define the kind of strategy to apply when performing vwap analysis **)
type strategy = ANNOT_PARAM | ANNOT_LABEL | ANNOT_FUN | ANNOT_ALL | ANNOT_NONE | ANNOT_LABPARAM

(* For assume insertion *)
let luncov_vwap_emitter = Emitter.create "LuncovVWAP"
    [ Emitter.Code_annot ] ~correctness:[] ~tuning:[];;

let print_label_status f data =
  let labels = Data.get_label_ids data in
  List.iter (fun i ->
      let l = Data.get_status data i in
      Format.fprintf f "label #%d: %a" i Data.pp_status l
    ) labels

let to_strategy s =
  match s with
  | "none" -> ANNOT_NONE
  | "all" -> ANNOT_ALL
  | "function" -> ANNOT_FUN
  | "param" -> ANNOT_PARAM
  | "label" ->ANNOT_LABEL
  | "label+param" -> ANNOT_LABPARAM
  | _ -> assert false

class annot_collector s id annots = object(self)
  inherit Visitor.frama_c_inplace

  val label_kf = Instrument.get_kf id
  val mutable in_label = false

  (* precond s \notin {ANNOT_NONE} *)
  method! vfunc fundec =
    let kf = Extlib.the self#current_kf in
    if kf == label_kf then
      begin
        if s = ANNOT_PARAM || s = ANNOT_LABPARAM || s = ANNOT_ALL then
          self#collect_param_annotations fundec;
        if s = ANNOT_PARAM then
          Cil.SkipChildren
        else
          Cil.DoChildren
      end
    else
      Cil.SkipChildren

  (* precond s \notin {ANNOT_NONE, ANNOT_PARAM} *)
  method! vstmt_aux stmt =
    match Instrument.is_stmt stmt with
    | Some lblid when lblid = id ->
      in_label <- true;
      self#collect_stmt_annotations stmt;
      Cil.ChangeDoChildrenPost (stmt, fun stmt -> in_label <- false; stmt)
    | _ ->
      if s = ANNOT_ALL || s = ANNOT_FUN || (in_label && s = ANNOT_LABEL) then
        self#collect_stmt_annotations stmt;
      Cil.DoChildren

  method private collect_param_annotations fdec =
    let vars = collect_fun_param fdec in 
    let first_stmt = List.hd fdec.sbody.bstmts in
    self#collect_value_annotations first_stmt vars

  method private collect_stmt_annotations stmt =
    let vars = collect_variables stmt in
    self#collect_value_annotations stmt vars

  method private collect_value_annotations stmt vars =
    let on_var var =
      match Commons.exp_to_pred stmt var with
      | Some p -> Queue.add (label_kf, stmt, p) annots
      | _ -> ()
    in
    Cil_datatype.ExpStructEq.Set.iter on_var vars

end

let add_future_annot (kf,stmt,pred) =
  Options.debug4 ~level:2 "add value annotation `%a` at %a"
    Printer.pp_predicate_named pred
    Printer.pp_location (Cil_datatype.Stmt.loc stmt);
  let code_annotation = Logic_const.new_code_annotation (AAssert ([], pred)) in
  Annotations.add_code_annot ~kf luncov_vwap_emitter stmt code_annotation;
  let props = Property.ip_of_code_annot kf stmt code_annotation in
  List.iter (fun prop -> Property_status.emit luncov_vwap_emitter ~hyps:[] prop Property_status.True) props;;


let wvap_property_checker strat valueprj =
  let _, wp_check = Wp.wp_property_checker in
  let check ~label ip =
    let new_ast = Ast.get() in
    let annots = Queue.create () in
    let collect_annots () =
      Visitor.visitFramacFile (new annot_collector strat label annots) new_ast
    in
    Commons.with_project valueprj collect_annots ();
    Queue.iter add_future_annot annots;
    wp_check ~label ip
  in
  ("WVAP", check)


let compute ?(force=false) data =
  let strat = to_strategy (Options.Strategy.get()) in

  Options.feedback "start combined detection (aka VWAP)";
  Options.debug2 "%a" print_label_status data;
  Value.compute ~force data;
  Options.debug2 "%a" print_label_status data;
  let prj = Project.current () in
  begin
    match strat with
    | ANNOT_NONE ->
      Wp.compute ~force data
    | _ ->
      Wp.compute ~force ~checker:(wvap_property_checker strat prj) data
  end;

  Options.debug2 "%a" print_label_status data;
  Options.feedback "combined detection done"

#!/bin/bash

BENCH_DIR="/home/robin/phd/labels/examples/benchs_ICST2014"
PLUGIN_DIR="/home/robin/phd/labels/luncov"

OUTPUT_DIR="/home/robin/phd/labels/bench_luncov"
RESULTS="RESULTS.txt"
STRATEGY="function"

declare -a DIRS=('apache_full_bad' 'apache_full_bad' 'apache_full_bad' 'apache_get_tag-5' 'apache_get_tag-5' 'apache_get_tag-5' 'apache_get_tag-6' 'apache_get_tag-6' 'apache_get_tag-6' 'Fourballs' 'libgd-5' 'libgd-5' 'libgd-5' 'libgd-6' 'libgd-6' 'libgd-6' 'Replace' 'TCAS' 'TCAS' 'TCAS' 'TriTyp' 'utf8-3' 'utf8-5')

declare -a FILES=('full_bad_CC' 'full_bad_MCC' 'full_bad_wm' 'iter1_prefixLong_arr_bad-CC' 'iter1_prefixLong_arr_bad-MCC' 'iter1_prefixLong_arr_bad-wm' 'iter1_prefixLong_arr_bad-CC' 'iter1_prefixLong_arr_bad-MCC' 'iter1_prefixLong_arr_bad-wm' 'Fourballs-wm1' 'gd_full_bad-CC' 'gd_full_bad-MCC' 'gd_full_bad-wm' 'gd_full_bad-CC' 'gd_full_bad-MCC' 'gd_full_bad-wm' 'Replace-wm' 'tcas-CC-simple' 'tcas-MCC-simple' 'tcas-wm-normalise' 'TriTyp-wm' 'checkutf8-wm' 'checkutf8-wm')

declare -a MAINS=('escape_absolute_uri' 'escape_absolute_uri' 'escape_absolute_uri' 'get_tag' 'get_tag' 'get_tag' 'get_tag' 'get_tag' 'get_tag' 'relativeWeight' 'gdImageStringFTEx' 'gdImageStringFTEx' 'gdImageStringFTEx' 'gdImageStringFTEx' 'gdImageStringFTEx' 'gdImageStringFTEx' 'getsub' 'alt_sep_test' 'alt_sep_test' 'alt_sep_test' 'triang' 'testmain' 'testmain')

mkdir -p $OUTPUT_DIR 2>/dev/null

NB_BENCH=${#DIRS[@]}
NB_BENCH=`expr $NB_BENCH - 1`
from="0"


for i in `seq 0 $NB_BENCH`
do
  echo "$i. ${DIRS[$i]}/${FILES[$i]}"
done
echo -n "Select the file to benchmark (default:all):"
read input

if [[ $input != "" ]]
then
  from=$input
  NB_BENCH=$input
fi

echo > "$OUTPUT_DIR/$RESULTS"

for bench_i in `seq $from $NB_BENCH`
do
  dir=${DIRS[$bench_i]}
  main=${MAINS[$bench_i]}
  file=${FILES[$bench_i]}
  src="$file.c"
  label_file=`printf "%s_%s.labels" $dir $file`

  echo -e "Bench $bench_i ($dir/$src)" | tee -a "$OUTPUT_DIR/$RESULTS"

  va_uncov=`grep 'uncoverable\|unreachable' $BENCH_DIR/$dir/$file.labels.luncov | wc -l`
  wp_uncov=`grep 'uncoverable\|unreachable' $BENCH_DIR/$dir/$file.labels.luncov-wp | wc -l`
  testgen_uncov=`grep unknown $BENCH_DIR/$dir/$file.labels.testgen | wc -l`
  
  T="$(date +%s)"
  frama-c -load-module ./LUncov -luncov-strategy $STRATEGY -slevel 50 -val-ilevel 64 -context-width 128 -main $main -lib-entry -no-warn-signed-overflow -wp-model Typed+cint -wp-timeout 1 -luncov -luncov-vwap -wp-verbose 0 -luncov-init -value-verbose 0 -luncov-labels $OUTPUT_DIR/$label_file $BENCH_DIR/$dir/$src
  T="$(($(date +%s)-T))"
  printf "Total: %02dm:%02ds\n" "$((T/60%60))" "$((T%60))" | tee -a "$OUTPUT_DIR/$RESULTS"
  vwap_uncov=`grep 'uncoverable\|unreachable' $OUTPUT_DIR/$label_file |wc -l`
  echo -e "Uncoverable: VA:$va_uncov WP:$wp_uncov VWAP:$vwap_uncov ($testgen_uncov)\n----" | tee -a "$OUTPUT_DIR/$RESULTS"

done

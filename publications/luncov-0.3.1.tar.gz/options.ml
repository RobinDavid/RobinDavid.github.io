(**************************************************************************)
(*                                                                        *)
(*  This file is part of Frama-C.                                         *)
(*                                                                        *)
(*  Copyright (C) 2013-2014                                               *)
(*    CEA (Commissariat à l'énergie atomique et aux énergies              *)
(*         alternatives)                                                  *)
(*                                                                        *)
(*  You may redistribute it and/or modify it under the terms of the GNU   *)
(*  Lesser General Public License as published by the Free Software       *)
(*  Foundation, version 2.1.                                              *)
(*                                                                        *)
(*  It is distributed in the hope that it will be useful, but WITHOUT     *)
(*  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY    *)
(*  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General      *)
(*  Public License for more details.                                      *)
(*                                                                        *)
(*  See the GNU Lesser General Public License version 2.1 for more        *)
(*  details (enclosed in the file LICENSE).                               *)
(*                                                                        *)
(**************************************************************************)

let () = Plugin.is_share_visible ()

include Plugin.Register
    (struct
      let name = "luncov"
      let shortname = "luncov"
      let help = "Uncoverable label detection"
    end)

module Enabled = False (struct
    let option_name = "-luncov"
    let help = "enable uncoverable label detection (disabled by default)"
  end)

let inits = add_group "Label data initialization"

let () = Parameter_customize.set_group inits
module Init = False (struct
    let option_name = "-luncov-init"
    let help = "(re-)initialize label data from source file"
  end)
let () = Init.add_set_hook (fun _old b -> if b then Enabled.on ())

let () = Parameter_customize.set_group inits
module ForceInit = False (struct
    let option_name = "-luncov-force-init"
    let help = "initialize label data from source file \
                (clearing any previous data first)"
  end)
let () = ForceInit.add_set_hook (fun _old b -> if b then Enabled.on ())

let methods = add_group "Detection methods"

let () = Parameter_customize.set_group methods
module WP = False (struct
    let option_name = "-luncov-wp"
    let help = "enable weakest precondition-based detection \
                (disabled by default, implies -luncov)"
  end)
let () = WP.add_set_hook (fun _old b -> if b then Enabled.on ())

let () = Parameter_customize.set_group methods
module Value = False (struct
    let option_name = "-luncov-value"
    let help = "enable value analysis-based detection \
                (enabled by default, implies -luncov)"
  end)
let () = Value.add_aliases [ "-luncov-va" ]
let () = Value.add_set_hook (fun _old b -> if b then Enabled.on ())

let () = Parameter_customize.set_group methods
module VWAP = False (struct
    let option_name = "-luncov-vwap"
    let help = "enable VA + WP computation \
                (disabled by default, implies -luncov)"
  end)
let () = VWAP.add_set_hook (fun _old b -> if b then Enabled.on ())

let general = add_group "General options"

let () = Parameter_customize.set_group general
module Force = False (struct
    let option_name = "-luncov-force"
    let help = "force the computation for all labels, \
                including those marked covered or uncoverable \
                (disabled by default)"
  end)

let () = Parameter_customize.set_group general
module Rte = False (struct
    let option_name = "-luncov-rte"
    let help = "add runtime error annotations for WP-based detection \
                (disabled by default), \
                see -rte-help for RTE generation parameters"
  end)

let () = Parameter_customize.set_group general
module LabelsFile = String (struct
    let default = ""
    let option_name = "-luncov-labels"
    let arg_name = "f"
    let help = "set the filename of the label data \
                (by default <input file>.labels)"
  end)


let () = Parameter_customize.set_group general
let strat_str = ["none";"all";"param";"function";"label";"label+param"]
module Strategy = String (struct
    let default = "label"
    let option_name = "-luncov-strategy"
    let arg_name = "strategy"
    let help = "set the strategy to use for annotating code ("^(List.fold_left (fun acc e -> acc^","^e) "" strat_str)^")"
  end)
let () = Strategy.set_possible_values strat_str

